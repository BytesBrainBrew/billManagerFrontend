export const statusCodeValue = {
    unauthorized: 401,
    badRequest: 404,
    statusOk:200,
    created: 201,
    conflict: 409
}