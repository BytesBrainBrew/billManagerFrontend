export type globalFieldType = {
    value: string | number,
    warning: boolean
}