export const API_URL = {
    login:"login",
    signUp:"signup",
    logout:"logout"
}