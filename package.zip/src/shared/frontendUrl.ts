export const frontendUrl = {
    login:"/",
    signUp:"/sign-up",
    dataInfoPage:"/data-info",
    notFound:"/404"
}