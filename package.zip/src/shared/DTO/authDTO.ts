export type loginDTO ={
    email: string;
    password: string
}
export type signUpDTO ={
    email: string;
    password: string;
    username: string
}