import { Outlet, Navigate } from "react-router-dom";
import { frontendUrl } from "../shared/frontendUrl";
import { getCookies } from "../shared/cookies";
const PrivateRoute = () => {
  const token = "getCookies()";
  console.log(getCookies())
  return token ? <Outlet /> : <Navigate to={frontendUrl.login} replace />;
};

export default PrivateRoute;
